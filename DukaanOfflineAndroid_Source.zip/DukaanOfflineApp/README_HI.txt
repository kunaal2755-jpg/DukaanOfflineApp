MOURYA DUKAAN OFFLINE ANDROID APP - SOURCE PROJECT

Is project mein naya offline app version hai. Purana PHP/MySQL data import nahi kiya gaya, jaise user ne kaha.

FEATURES
- Products / building material stock
- Customers and opening udhar
- Tiles / marbles stock (boxes + loose pieces)
- Sales and pending/confirmed status
- Confirm sale par stock reduce; confirmed sale delete karte waqt stock restore option
- Bill view and Print / Save PDF (Android print service par depend karta hai)
- JSON backup export / restore
- Data phone par localStorage mein save hota hai; internet, hosting aur domain ki zaroorat nahi

IMPORTANT
- Yeh Android Studio project/source ZIP hai, compiled APK nahi.
- APK banane ke liye Android Studio ya compatible Android build environment chahiye. Project ko Android Studio mein open karke Gradle sync aur Build > Build APK(s) karein.
- App data isi phone par rehta hai. App uninstall/data clear karne se data mit sakta hai. Backup export regular karein.
- WhatsApp par bill automatic attach karna is starter app mein include nahi hai.
